import java.io.BufferedReader
import java.io.FileReader
import java.io.FileWriter // Por si quiero desear un CSV con los resultados en un proyecto posterior
import java.util.*


fun main() {
    // Adjunto el archivo y le doy el nombre de salida al CSV que resulte de la criba
    val csvFileName = "/Users/agustrodmar/IdeaProjects/buscadorPalabras/itinerarios.csv"
    /// val csvResultante = "AAD.csv" /// Por si quiero generar un CSV con los resultados en un proyecto posterior

    /// val csvWriter = FileWriter(csvResultante) Por si quiero generar un CSV con los resultados en un proyecto posterior
    var continuar = true // condición para que el usuario busque todo el tiempo que quiera

    while (continuar) {

        // Creo la variable linea y el reader dentro del bucle para crear un nuevo lector con cada búsqueda
        var line: String?
        val csvReader = BufferedReader(FileReader(csvFileName))

        // Variable para controlar si se han encontrado resultados
        var resultadosEncontrados = false

        // Pido al usuario que ingrese el texto que desea buscar dentro del CSV
        println("Ingrese el fragmento de texto que desea encontrar: ")
        val busqueda = readLine() ?: ""

        // Bucle while para leer el archivo CSV linea a linea
        while (csvReader.readLine().also { line = it } != null) {
            // Verifica si el texto que ha ingresado el usuario está en la linea, ignoro las mayúsculas.
            if (line != null && line!!.contains(busqueda, ignoreCase = true)) {
                println(line)
                resultadosEncontrados = true
            }
        }

        //Si no se encuentran resultados, informo al usuario
        if (!resultadosEncontrados){
            println("No se encontraron resultados en la base de datos.")
        }

        // Pregunto al usuario si quiere seguir buscando dentro de la base de datos
        println("¿Desea realizar otra búsqueda? (Sí/No): ")
        val respuesta = readLine()?.trim()?.lowercase(Locale.getDefault())

        // Rompo el bucle
        if (respuesta == "no") {
            continuar = false
        }
        // Cierro el reader después de cada iteración del bucle para ahorrar en recursos.
        csvReader.close()

    }
    /// csvWriter.close()
}
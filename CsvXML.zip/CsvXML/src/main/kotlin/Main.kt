import java.io.BufferedReader
import java.io.FileReader
import java.io.FileWriter

fun main() {
    // Adjunto el archivo y le doy nombre de salida al archivo XML
    val csvFileName = "/Users/agustrodmar/IdeaProjects/CsvXML/consumers-price-index-june-2023-quarter-seasonally-adjusted.csv"
    val xmlFileName = "ADA.xml"

    // Creo un lector para el archivo CSV y un escritor para el archivo XML
    val csvReader = BufferedReader(FileReader(csvFileName))
    val xmlWriter = FileWriter(xmlFileName)

    // La declaración XML
    xmlWriter.write("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n")
    xmlWriter.write("<Price_index>\n")

    var line: String?
    var isFirstLine = true

    // Bucle while para leer el archivo CSV línea por línea
    while (csvReader.readLine().also { line = it } != null) {
        // Ignoro los encabezados
        if (isFirstLine) {
            isFirstLine = false
            continue
        }

        // Divido la línea en tokens utilizando comas como separadores
        val tokens = line!!.split(",")
        if (tokens.size == 9) {
            val series_reference = tokens[0]
            val period = tokens[1]
            val data_value = tokens[2]
            val status = tokens[3]
            val units = tokens[4]
            val subject = tokens[5]
            val group = tokens[6].replace("\"", "") // Uso replace para eliminar comillas.
            val series_title = tokens.slice(8 until tokens.size).joinToString(",") // Slice me permite discriminar la coma de series_title.

            // Escribir información en el XML
            xmlWriter.write("    <consumer_index>\n")
            xmlWriter.write("        <series_reference>$series_reference</series_reference>\n")
            xmlWriter.write("        <period>$period</period>\n")
            xmlWriter.write("        <data_value>$data_value</data_value>\n")
            xmlWriter.write("        <status>$status</status>\n")
            xmlWriter.write("        <units>$units</units>\n")
            xmlWriter.write("        <subject>$subject</subject>\n")
            xmlWriter.write("        <group>$group</group>\n")
            xmlWriter.write("        <series_title>$series_title</series_title>\n")
            xmlWriter.write("    </consumer_index>\n")
        }
    }

    // Cierro la etiqueta raíz del XML y los archivos
    xmlWriter.write("</Price_index>\n")
    xmlWriter.close()
    csvReader.close()
    println("Archivo XML generado exitosamente.")
}
